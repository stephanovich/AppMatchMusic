package com.example.matchmusic.Model

class ArtistAndMusics(
    var imagem_artista: String? = null,
    var nome_artista: String? = null,
    var nome_musica: String? = null
) {
}