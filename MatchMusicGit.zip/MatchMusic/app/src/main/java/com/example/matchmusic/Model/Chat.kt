package com.example.matchmusic.Model

class Chat {
    var emailUsuarioLogado: String? = null
    var emailUsuarioAmigo: String? = null
    var mensagens: List<String>? = null
}