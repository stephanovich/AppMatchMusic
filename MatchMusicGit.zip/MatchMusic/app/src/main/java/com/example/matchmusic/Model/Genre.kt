package com.example.matchmusic.Model

class Genre(
    var data: List<Artist>
) {
    var name: String? = null
}