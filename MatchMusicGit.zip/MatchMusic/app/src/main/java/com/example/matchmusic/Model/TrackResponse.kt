package com.example.matchmusic.Model

class TrackResponse(var data: List<Track>) {
}