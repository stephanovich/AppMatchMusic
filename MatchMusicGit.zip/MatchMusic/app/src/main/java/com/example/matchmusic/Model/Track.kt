package com.example.matchmusic.Model

class Track(){
    var id: Long? = null
    var readable: Boolean? = null
    var title: String? = null
    var title_short: String? = null
    var artist: Artist? = null
}