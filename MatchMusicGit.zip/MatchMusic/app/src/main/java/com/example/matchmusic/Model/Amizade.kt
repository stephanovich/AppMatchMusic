package com.example.matchmusic.Model

class Amizade {
    var solicitante: String = ""
    var solicitado: String = ""
    var confirmacao: Boolean = false
}